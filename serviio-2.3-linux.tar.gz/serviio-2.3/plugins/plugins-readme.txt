Place online plugins (.groovy files) in this directory. Serviio will automatically detect them
and they will be ready to gather feed information in a few moments.

If you are interested in developing plugins, find some information in the wiki 
(http://wiki.serviio.org/doku.php?id=servio_plugins).